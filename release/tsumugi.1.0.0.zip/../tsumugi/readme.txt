=== tsumugi ===

Contributors: youthkee
Tags: white, blue, light, responsive-layout, one-column, custom-menu, custom-header

Requires at least: 4.0
Tested up to: 4.4.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

tsumugi is a simple blog theme based on _s and Bootstrap. It consists of a single column layout which is suitable for mobile devices and tablets along with PCs. For it's readability and simplicity, this theme is user-friendly for everyone. (The name of "tsumugi" is inspired by the song of "Hatsune", a Japanese singer.)

=== Features ===

* Responsive Layout
* Global Navigation (in header)
* Widget (in footer)
* Theme Customizer
* Custom Header

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.0 - Apr 30 2016 =
* Initial release

== Credits ==

Bootstrap 4
License: MIT
Source : http://v4-alpha.getbootstrap.com/

Google Fonts:
License: SIL Open Font License, 1.1
Source:  http://www.google.com/fonts

Font Awesome
Font License: SIL OFL 1.1
Code License: MIT License
Source      : https://fortawesome.github.io/Font-Awesome/

* Based on Underscores http://underscores.me/, (C) 2012-2016 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
